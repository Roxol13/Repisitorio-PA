package com.ProyectoDeAula5.Proyecto5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
