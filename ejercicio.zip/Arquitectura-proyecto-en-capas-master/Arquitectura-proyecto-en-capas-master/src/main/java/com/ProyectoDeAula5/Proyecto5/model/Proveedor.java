package com.tecnologicocomfenalco.tiendavirtual.models.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int ruc;

    private String nombre;

    private int telefono;

    private int ubicacion;

    private int razon;


}