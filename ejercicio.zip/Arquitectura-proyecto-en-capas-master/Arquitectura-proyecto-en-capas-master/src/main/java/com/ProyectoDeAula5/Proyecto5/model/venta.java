package com.tecnologicocomfenalco.tiendavirtual.models.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private string codProducto;
    private String codCliente;
    private String codEmpleado;
    private String descripcionP;
    private string fecha;
    private double subtotal;


}