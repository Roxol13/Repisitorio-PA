package com.ProyectoDeAula5.Proyecto5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto5Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto5Application.class, args);
	}

}
